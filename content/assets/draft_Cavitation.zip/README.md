# Nanobubble Nucleation and Growth in Confinement

This project provides a comprehensive Molecular Dynamics (MD) framework using LAMMPS to simulate and analyze the behavior of nanobubbles in various confined geometries, including nanochannels, slit pores, and chambers. It focuses on nucleation processes, cavity expansion, and the impact of surface hydrophobicity on bubble stability.

## 1. Physical and Mathematical Foundations

### 1.1 Water Model: TIP4P/2005
The simulations utilize the TIP4P/2005 rigid water model. It consists of four sites:
- **Oxygen (O)**: Lennard-Jones (LJ) center.
- **Hydrogen (H)**: Two sites with positive charges.
- **M-site**: A virtual site located along the bisector of the H-O-H angle where the negative charge of oxygen is placed.

**Potential Energy Functions:**
The total potential energy is the sum of Lennard-Jones and Coulombic interactions:
$$U_{total} = \sum_{i<j} \left( 4\epsilon_{ij} \left[ \left(\frac{\sigma_{ij}}{r_{ij}}\right)^{12} - \left(\frac{\sigma_{ij}}{r_{ij}}\right)^6 \right] + \frac{1}{4\pi\epsilon_0} \frac{q_i q_j}{r_{ij}} \right)$$

### 1.2 Fluid Mechanics of Evaporation and Confinement
Beyond molecular interactions, the project analyzes the macro-scale behavior of moisture and evaporation using the following logic:

**Evaporation Rate ($Q_v$):**
Assuming moisture content $y$ and vapor pressure $p$, the evaporation rate for an airflow $Q_{air}$ is given by:
$$Q_v = Q_{air} \cdot |y_{sat} - y_{act}|$$
At $P = 1$ atm, this simplifies to:
$$Q_v = Q_{air} \cdot |p_{sat} - p_{act}|$$

**Hydraulic Resistance ($R_{hy}$) and Pressure Drop ($\Delta P$):**
The pressure drop across a channel due to evaporation/flow follows the Hagen–Poiseuille law analogy:
$$\Delta P = R_{hy} \cdot Q_v = R_{hy} \cdot Q_{air} \cdot |p_{sat} - p_{act}|$$

For a rectangular channel of width $w$, height $h$, and length $l$, the hydraulic resistance is calculated as:
$$R_{hy} = \frac{12 \eta l}{\left(1 - 0.63 \frac{h}{w}\right) h^3 w}$$
*Note: To mitigate negative induced pressure, the geometry must satisfy the condition $w > 0.63 \cdot h$.*

### 1.3 Custom Wall Potential (LJ 12-6)
A custom wall-particle interaction is implemented in `lmps_fix_wall_lj126.cpp`. It describes a flat wall interacting with particles (typically Oxygen atoms) via a modified 12-6 Lennard-Jones potential:
$$U_{wall}(z) = 4\epsilon \left[ \left(\frac{\sigma}{z}\right)^{12} - \alpha_{hydro} \cdot \left(\frac{\sigma}{z}\right)^6 \right]$$
where:
- $z$ is the perpendicular distance to the wall.
- $\epsilon$ and $\sigma$ are the interaction parameters.
- $\alpha_{hydro}$ is a **hydrophobicity parameter**. $\alpha_{hydro}=1.0$ represents standard interaction, while $\alpha_{hydro} < 1.0$ increases hydrophobicity by weakening the attraction.

The force exerted by the wall on a particle is:
$$F_{wall}(z) = -\frac{dU_{wall}}{dz} = \frac{4\epsilon}{z} \left[ 12\left(\frac{\sigma}{z}\right)^{12} - 6\alpha_{hydro}\left(\frac{\sigma}{z}\right)^6 \right]$$

### 1.4 Simulation Ensembles and Algorithms
- **NPT (Isobaric-Isothermal)**: Used for initial equilibration to reach target system density at specified pressure ($P$) and temperature ($T$).
- **NVE (Microcanonical)**: Used for production runs, often combined with a Berendsen thermostat for stability.
- **SHAKE Algorithm**: Enforces rigidity of the water molecules by constraining O-H bond lengths and H-O-H angles.
- **PPPM (Particle-Particle Particle-Mesh)**: Used for calculating long-range electrostatic interactions.

### 1.5 Bubble Nucleation and Growth Logic
- **Nucleation via Evaporation**: A spherical region of radius $R_{bubble}$ is defined. Molecules within this region are removed using `fix evaporate`, creating a vacuum void (the nanobubble).
- **Expansion via Deformation**: For cavitation studies, the simulation box is expanded in the $x$-direction using `fix deform`. The cavity growth is driven by the rate of expansion:
  $$\frac{dL}{dt} = \text{rate}$$
- **Stubborn Bubbles**: A logic implemented via the `stubborn` variable to control whether the evaporation fix is persistent or a one-time event.

## 2. File Descriptions

### 2.1 LAMMPS Input Scripts (.lmps / .in)
Scripts are specialized for different scenarios:
- `bubble_insert_centered_...`: Inserts a spherical nanobubble at the center of a liquid-filled channel.
- `chamber_channel_expansion.lmps`: Models a system with a large reservoir (chamber) connected to a nanochannel. Implements box deformation to study expansion.
- `evaporation_channel_and_slit_npt.lmps`: Focuses on evaporation and liquid-vapor interface behavior in slit pores.
- `parallel_walls_z_npt_nve_expansion_compute.in`: Basic setup for confinement between two parallel walls in the Z-direction.
- `slit_pore_expansion_by_fixdeform_no_remap.lmps`: Specifically for slit pore geometries under expansion.
- `expansion_by_changebox_...` vs `expansion_by_fixdeform_...`: Compares different methods of box expansion (`change_box` vs `fix deform`).

### 2.2 Analysis Scripts (Python)
- `dump2csv_mesh_allocation.py`:
  - Performs 3D spatial binning.
  - Calculates local density:
    $$\rho_{cell} = \frac{\sum m_i}{V_{cell}}$$
  - Outputs 1D density profiles (slabs) along X, Y, and Z.
  - Outputs 3D density maps to identify bubbles (regions where $\rho \approx 0$).
- `dump_molecules_1.py`:
  - Parses dump files and groups atoms into molecules.
  - Calculates molecular-level statistics.
  - Identifies "empty bins" as probable nucleation sites.
- `CG_r2d4A_..._plotter_...`: Coarse-graining scripts for visualizing 3D density distributions and isosurfaces.
- `log2csv_plotter.py`: Parses LAMMPS log files to extract and plot thermodynamic data (Temperature, Pressure, Energy).

### 2.3 Custom C++ Source
- `lmps_fix_wall_lj126.cpp` / `.h`: The implementation of the tunable LJ 12-6 wall potential. Must be compiled into LAMMPS as a user package or custom fix.

### 2.4 Supporting Files
- `TIP4P2005.txt`: Molecule template file for the water model.
- `run.pbs`, `runner.sh`, `scheduler.sh`: Shell and batch scripts for job submission on HPC clusters.

## 3. Usage Instructions

### 3.1 Prerequisites
- **LAMMPS**: Must be built with `MOLECULE`, `KSPACE`, and `RIGID` packages. The custom `fix wall/lj126` must be added to the source and recompiled.
- **Python 3**: Requires `numpy`, `pandas`, `scipy`, and `matplotlib`.

### 3.2 Running a Simulation
1.  **Preparation**: Ensure `TIP4P2005.txt` is in the working directory.
2.  **Execution**: Run LAMMPS using the desired input script:
    ```bash
    lmp_serial -in bubble_insert_centered_noEXP_fix_stubborn_no.lmps
    ```
    Or via PBS on a cluster:
    ```bash
    qsub run.pbs
    ```

### 3.3 Post-Processing Analysis
1.  **Extract Density Poly-Profiles**:
    Use the mesh allocation script on a dump file:
    ```bash
    python dump2csv_mesh_allocation.py dump.bubble.100000
    ```
2.  **Identify Nucleation Sites**:
    ```bash
    python dump_molecules_1.py dump.bubble.100000
    ```
3.  **Visualization**:
    Use the coarse-graining plotter scripts to generate 3D plots of the density distribution.

## 4. Mathematical Mesh Allocation Logic
The discretization of the domain is performed as follows:
1.  A resolution $L \approx 2.75$ Å (water molecule diameter) is chosen.
2.  Bins are defined with sizes $B \in \{1L, 2L, 5L, 7.5L, 10L\}$.
3.  The bin volume is $V_{bin} = \Delta x \Delta y \Delta z$.
4.  Mass $M_{bin} = \sum_{i \in bin} m_i$.
5.  Density:
    $$\rho_{bin} = \frac{M_{bin}}{V_{bin}}$$
6.  A cell is considered a "void" or "bubble" if $\rho_{bin} < \rho_{threshold}$ (typically $10^{-6}$ in simulation units).
