lines = []
lines.append("variable nA0 equal count(nA)")
lines.append("variable nB0 equal count(nB)")
for i in range(1, 10):
    lines.append(f"variable nAA{i}0 equal count(nAA{i})")
for i in range(1, 10):
    lines.append(f"variable nAB{i}0 equal count(nAB{i})")
for i in range(1, 4):
    lines.append(f"variable nBB{i}0 equal count(nBB{i})")
content = "\n".join(lines) + "\n"
with open("dynamics_compute_n_groups.lmp", "w") as f:
    f.write(content)