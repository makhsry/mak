lines = []
for g in ["nA", "nB"]:
    lines.append(f"group {g} delete")
for i in range(1, 10):
    lines.append(f"group nAA{i} delete")
for i in range(1, 10):
    lines.append(f"group nAB{i} delete")
for i in range(1, 4):
    lines.append(f"group nBB{i} delete")
content = "\n".join(lines) + "\n"
with open("dynamics_clean_groups.lmp", "w") as f:
    f.write(content)