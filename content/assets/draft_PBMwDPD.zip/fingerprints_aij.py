lines = []
lines.append("# values in kcal/mol")
lines.append("variable V1 equal 1")
lines.append("variable V2 equal 1")
# Pattern: variable a_i_j equal ${V1}+${V2}*${X_i_j}
for i in range(1, 24):
    for j in range(1, 24):
        lines.append(f"variable a_{i}_{j} equal ${{V1}}+${{V2}}*${{X_{i}_{j}}}")
content = "\n".join(lines) + "\n"
with open("fingerprints_aij.lmp", "w") as f:
    f.write(content)