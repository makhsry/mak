def generate_aa_block(i):
    lines = []
    lines.append(f"#--- AA{i} --- B")
    lines.append(f"variable nAA{i}_B equal round(${{kAA{i}eB}}*(${{nA0}})*(${{nA0}})*(step*dt))")
    lines.append(f"if ${{nAA{i}_B}}>${{nA0}} then 'variable nAA{i}_B equal ${{nA0}}'")
    lines.append(f"create_atoms {3+i} random ${{nAA{i}_B}} ${{seed}} NULL overlap ${{RcG}} maxtry 1000000")
    lines.append(f"delete_atoms random count ${{nAA{i}_B}} yes nA NULL ${{seed}} compress yes")
    lines.append(f"#--- AA{i} --- D ")
    lines.append(f"variable nAA{i}_D equal round(${{kAA{i}eD}}*(${{nAA{i}0}})*(step*dt))")
    lines.append(f"variable dummy equal ${{nAA{i}0}}+${{nAA{i}_B}}")
    lines.append(f"if ${{nAA{i}_D}}>${{dummy}} then 'variable nAA{i}_D equal ${{dummy}}'")
    lines.append(f"delete_atoms random count ${{nAA{i}_D}} yes nAA{i} NULL ${{seed}} compress yes")
    lines.append(f"create_atoms 1 random ${{nAA{i}_D}} ${{seed}} NULL overlap ${{RcG}} maxtry 1000000")
    return lines

def generate_bb_block(i):
    lines = []
    lines.append(f"#--- BB{i} --- B")
    lines.append(f"variable nBB{i}_B equal round(${{kBB{i}eB}}*(${{nB0}})*(${{nB0}})*(step*dt))")
    lines.append(f"if ${{nBB{i}_B}}>${{nB0}} then 'variable nBB{i}_B equal ${{nB0}}'")
    lines.append(f"create_atoms {20+i} random ${{nBB{i}_B}} ${{seed}} NULL overlap ${{RcG}} maxtry 1000000")
    lines.append(f"delete_atoms random count ${{nBB{i}_B}} yes nB NULL ${{seed}} compress yes")
    lines.append(f"#--- BB{i} --- D ")
    lines.append(f"variable nBB{i}_D equal round(${{kBB{i}eD}}*(${{nBB{i}0}})*(step*dt))")
    lines.append(f"variable dummy equal ${{nBB{i}0}}+${{nBB{i}_B}}")
    lines.append(f"if ${{nBB{i}_D}}>${{dummy}} then 'variable nBB{i}_D equal ${{dummy}}'")
    lines.append(f"delete_atoms random count ${{nBB{i}_D}} yes nBB{i} NULL ${{seed}} compress yes")
    lines.append(f"create_atoms 2 random ${{nBB{i}_D}} ${{seed}} NULL overlap ${{RcG}} maxtry 1000000")
    return lines

def generate_ab_block(i):
    lines = []
    lines.append(f"#--- AB{i} --- B")
    lines.append(f"variable STU equal ${{nA0}}")
    lines.append(f"if ${{nA0}}>${{nB0}} then 'variable STU equal ${{nB0}}'")
    lines.append(f"variable stuSUM equal 2*${{STU}}")
    lines.append(f"if ${{nB0}}>${{nA0}} then 'variable STU equal ${{nA0}}'")
    lines.append(f"variable stuSUM equal 2*${{STU}}")
    lines.append(f"variable nAB{i}_B equal round(${{kAB{i}eB}}*(${{nA0}})*(${{nB0}})*(step*dt))")
    lines.append(f"if ${{nAB{i}_B}}>${{stuSUM}} then 'variable nAB{i}_B equal ${{stuSUM}}'")
    lines.append(f"create_atoms {11+i} random ${{nAB{i}_B}} ${{seed}} NULL overlap ${{RcG}} maxtry 1000000")
    lines.append(f"variable dummy equal round(${{nAB{i}_B}}/2)")
    lines.append(f"variable DEL equal ${{dummy}}")
    lines.append(f"if ${{dummy}}>${{nA0}} then 'variable DEL equal ${{nA0}}'")
    lines.append(f"delete_atoms random count ${{DEL}} yes nA NULL ${{seed}} compress yes")
    lines.append(f"variable DEL equal ${{dummy}}")
    lines.append(f"if ${{dummy}}>${{nB0}} then 'variable DEL equal ${{nB0}}'")
    lines.append(f"delete_atoms random count ${{DEL}} yes nB NULL ${{seed}} compress yes")
    lines.append(f"#--- AB{i} --- D ")
    lines.append(f"variable nAB{i}_D equal round(${{kAB{i}eD}}*(${{nAB{i}0}})*(step*dt))")
    lines.append(f"variable dummy equal ${{nAB{i}0}}+${{nAB{i}_B}}")
    lines.append(f"if ${{nAB{i}_D}}>${{dummy}} then 'variable nAB{i}_D equal ${{dummy}}'")
    lines.append(f"delete_atoms random count ${{nAB{i}_D}} yes nAB{i} NULL ${{seed}} compress yes")
    lines.append(f"variable dummy equal round(${{nAB{i}_D}}/2)")
    lines.append(f"create_atoms 1 random ${{dummy}} ${{seed}} NULL overlap ${{RcG}} maxtry 1000000")
    lines.append(f"create_atoms 2 random ${{dummy}} ${{seed}} NULL overlap ${{RcG}} maxtry 1000000")
    return lines

lines = []
for i in range(1, 10):
    lines.extend(generate_aa_block(i))
for i in range(1, 4):
    lines.extend(generate_bb_block(i))
for i in range(1, 10):
    lines.extend(generate_ab_block(i))
content = "\n".join(lines) + "\n"
with open("dynamics_compute_events.lmp", "w") as f:
    f.write(content)