def generate_kinetic_var(prefix, indices, event):
    """Generate kinetic rate variable for given indices"""
    lines = []
    formula = "((${kB}*${T})/(${nAv}*${h}))*exp(-1*${" + prefix + "{i}{event}}/${Rg}*${T}))"
    for i in indices:
        lines.append(f"variable k{prefix}{i}{event} equal {formula.format(prefix=prefix, i=i, event=event)}")
    return lines

lines = []
bb_indices = [1, 2, 3]
lines.extend(generate_kinetic_var("BB", bb_indices, "eB"))
lines.extend(generate_kinetic_var("BB", bb_indices, "eD"))
aa_indices = range(1, 10)
lines.extend(generate_kinetic_var("AA", aa_indices, "eB"))
lines.extend(generate_kinetic_var("AA", aa_indices, "eD"))
ab_indices = range(1, 10)
lines.extend(generate_kinetic_var("AB", ab_indices, "eB"))
lines.extend(generate_kinetic_var("AB", ab_indices, "eD"))
content = "\n".join(lines) + "\n"
with open("dynamics_compute_kinetic.lmp", "w") as f:
    f.write(content)