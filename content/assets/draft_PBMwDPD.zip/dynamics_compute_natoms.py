lines = []
lines.append("variable nA0 atom type==1")
lines.append("variable nB0 atom type==2")
for i in range(1, 10):
    lines.append(f"variable nAA{i}0 atom type=={2+i}")
for i in range(1, 10):
    lines.append(f"variable nAB{i}0 atom type=={11+i}")
for i in range(1, 4):
    lines.append(f"variable nBB{i}0 atom type=={20+i}")
lines.append("variable nTot equal atoms")
content = "\n".join(lines) + "\n"
with open("dynamics_compute_natoms.lmp", "w") as f:
    f.write(content)