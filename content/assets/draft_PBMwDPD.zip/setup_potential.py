lines = []
lines.append("# inputs_potential")
lines.append("# aij 		A (force units)")
lines.append("# aij 		gamma (force/velocity units) / (1A/fs)")
lines.append("# RcG 		cutoff (distance units)")
# Pattern: pair_coeff i j ${a_i_j} ${a_i_j} ${RcG}
for i in range(1, 24):
    for j in range(1, 24):
        lines.append(f"pair_coeff {i} {j} ${{a_{i}_{j}}} ${{a_{i}_{j}}} ${{RcG}}")
content = "\n".join(lines) + "\n"
with open("setup_potential.lmp", "w") as f:
    f.write(content)