dOMGidz.m
function [dOMG1dz dOMG2dz dOMG3dz]=dOMGidz(dOMG1dz,dOMG2dz,dOMG3dz,...
    ijOMG1,ijOMG2,ijOMG3,jIter,iIter,dz)
% Determining dOMGidz
dOMG1=ijOMG1(jIter,iIter)-ijOMG1(jIter-1,iIter);
dOMG2=ijOMG2(jIter,iIter)-ijOMG2(jIter-1,iIter);
dOMG3=ijOMG3(jIter,iIter)-ijOMG3(jIter-1,iIter);
%
dOMG1dz(jIter,iIter)=dOMG1/dz;
dOMG2dz(jIter,iIter)=dOMG2/dz;
dOMG3dz(jIter,iIter)=dOMG3/dz;
end
% End of nested m-file.
```

- **`d2OMGidz2.m`**

```bash
function [d2OMG1dz d2OMG2dz dOMG3dz]=d2OMGidz2(d2OMG1dz,d2OMG2dz,dOMG3dz,...
    ijOMG1,ijOMG2,jIter,iIter,dz,dzz)
% This Scripts Determines d2OMGidz2
d2OMG1dz(jIter,iIter)=(ijOMG1(jIter,iIter)-2*ijOMG1(jIter-1,iIter)...
    +ijOMG1(jIter-2,iIter))/(dzz+dz);
d2OMG2dz(jIter,iIter)=(ijOMG2(jIter,iIter)-2*ijOMG2(jIter-1,iIter)...
    +ijOMG2(jIter-2,iIter))/(dzz+dz);
d2OMG3dz(jIter,iIter)=-d2OMG1dz(jIter,iIter)-d2OMG2dz(jIter,iIter);
end
% End of nested m-file.